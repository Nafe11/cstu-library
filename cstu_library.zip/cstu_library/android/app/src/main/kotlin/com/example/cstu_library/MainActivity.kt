package com.example.cstu_library

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
