import 'package:flutter_test/flutter_test.dart';
import 'package:cstu_library/models/issue_model.dart';
import 'package:cstu_library/models/book_model.dart';

void main() {
  group('CSTU Library Unit Tests', () {
    test('University departments list contains 8 core faculties', () {
      expect(UniversityDepartments.list.length, 8);
      expect(UniversityDepartments.list, contains('CSE'));
      expect(UniversityDepartments.list, contains('EEE'));
      expect(UniversityDepartments.list, contains('Civil Engineering'));
      expect(UniversityDepartments.list, contains('BBA'));
      expect(UniversityDepartments.list, contains('English'));
      expect(UniversityDepartments.list, contains('Mathematics'));
      expect(UniversityDepartments.list, contains('Physics'));
      expect(UniversityDepartments.list, contains('Chemistry'));
    });

    test('IssueModel fine calculation - not overdue has 0 fine', () {
      final now = DateTime.now();
      final issue = IssueModel(
        id: 'issue-1',
        userId: 'student-1',
        userName: 'Sakib',
        userEmail: 'sakib@cstu.ac.bd',
        bookId: 'book-1',
        bookTitle: 'Database System Concepts',
        issueDate: now.subtract(const Duration(days: 5)),
        dueDate: now.add(const Duration(days: 9)),
        status: 'Active',
      );

      expect(issue.isOverdue, isFalse);
      expect(issue.overdueDays, 0);
      expect(issue.fine, 0);
      expect(issue.displayStatus, 'Active');
    });

    test('IssueModel fine calculation - 3 days overdue calculates ৳15 (৳5/day)', () {
      final now = DateTime.now();
      final issue = IssueModel(
        id: 'issue-2',
        userId: 'student-2',
        userName: 'Rahim',
        userEmail: 'rahim@cstu.ac.bd',
        bookId: 'book-2',
        bookTitle: 'Computer Networking',
        issueDate: now.subtract(const Duration(days: 17)),
        dueDate: now.subtract(const Duration(days: 3)),
        status: 'Active',
      );

      expect(issue.isOverdue, isTrue);
      expect(issue.overdueDays, greaterThanOrEqualTo(3));
      expect(issue.fine, equals(issue.overdueDays * 5));
      expect(issue.displayStatus, 'Overdue');
    });
  });
}
