import 'package:cloud_firestore/cloud_firestore.dart';

class BookModel {
  final String id;
  final String title;
  final String author;
  final String isbn;
  final String department;
  final String shelf;
  final int quantity;
  final int available;
  final String description;
  final DateTime? createdAt;

  BookModel({
    required this.id,
    required this.title,
    required this.author,
    required this.isbn,
    required this.department,
    required this.shelf,
    required this.quantity,
    required this.available,
    required this.description,
    this.createdAt,
  });

  bool get isAvailable => available > 0;

  factory BookModel.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>? ?? {};
    return BookModel(
      id: doc.id,
      title: data['title'] as String? ?? '',
      author: data['author'] as String? ?? '',
      isbn: data['isbn'] as String? ?? '',
      department: data['department'] as String? ?? '',
      shelf: data['shelf'] as String? ?? '',
      quantity: (data['quantity'] as num?)?.toInt() ?? 0,
      available: (data['available'] as num?)?.toInt() ?? 0,
      description: data['description'] as String? ?? '',
      createdAt: data['createdAt'] is Timestamp
          ? (data['createdAt'] as Timestamp).toDate()
          : null,
    );
  }

  Map<String, dynamic> toFirestore() {
    return {
      'title': title,
      'author': author,
      'isbn': isbn,
      'department': department,
      'shelf': shelf,
      'quantity': quantity,
      'available': available,
      'description': description,
      'createdAt': createdAt != null
          ? Timestamp.fromDate(createdAt!)
          : FieldValue.serverTimestamp(),
    };
  }
}

class UniversityDepartments {
  static const List<String> list = [
    'CSE',
    'EEE',
    'Civil Engineering',
    'BBA',
    'English',
    'Mathematics',
    'Physics',
    'Chemistry',
  ];
}
