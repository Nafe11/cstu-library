import 'package:cloud_firestore/cloud_firestore.dart';

class IssueModel {
  final String id;
  final String userId;
  final String userName;
  final String userEmail;
  final String bookId;
  final String bookTitle;
  final DateTime issueDate;
  final DateTime dueDate;
  final String status; // 'Active', 'Returned'
  final int storedFine;
  final DateTime? returnedAt;

  IssueModel({
    required this.id,
    required this.userId,
    required this.userName,
    required this.userEmail,
    required this.bookId,
    required this.bookTitle,
    required this.issueDate,
    required this.dueDate,
    required this.status,
    this.storedFine = 0,
    this.returnedAt,
  });

  /// Check if the issue is currently overdue.
  bool get isOverdue {
    if (status == 'Returned') return false;
    final now = DateTime.now();
    return now.isAfter(dueDate);
  }

  /// Number of days overdue (0 if not overdue).
  int get overdueDays {
    final comparisonDate = returnedAt ?? DateTime.now();
    if (comparisonDate.isAfter(dueDate)) {
      // Calculate full days overdue
      final difference = comparisonDate.difference(dueDate);
      final days = difference.inDays;
      // If there is any fractional day past due date, count as overdue day
      return days > 0 ? days : 1;
    }
    return 0;
  }

  /// ৳5 per overdue day
  int get fine {
    if (status == 'Returned') {
      return storedFine;
    }
    return overdueDays * 5;
  }

  /// Current display status: 'Overdue', 'Active', or 'Returned'
  String get displayStatus {
    if (status == 'Returned') return 'Returned';
    return isOverdue ? 'Overdue' : 'Active';
  }

  factory IssueModel.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>? ?? {};
    return IssueModel(
      id: doc.id,
      userId: data['userId'] as String? ?? '',
      userName: data['userName'] as String? ?? '',
      userEmail: data['userEmail'] as String? ?? '',
      bookId: data['bookId'] as String? ?? '',
      bookTitle: data['bookTitle'] as String? ?? '',
      issueDate: data['issueDate'] is Timestamp
          ? (data['issueDate'] as Timestamp).toDate()
          : DateTime.now(),
      dueDate: data['dueDate'] is Timestamp
          ? (data['dueDate'] as Timestamp).toDate()
          : DateTime.now().add(const Duration(days: 14)),
      status: data['status'] as String? ?? 'Active',
      storedFine: (data['fine'] as num?)?.toInt() ?? 0,
      returnedAt: data['returnedAt'] is Timestamp
          ? (data['returnedAt'] as Timestamp).toDate()
          : null,
    );
  }

  Map<String, dynamic> toFirestore() {
    return {
      'userId': userId,
      'userName': userName,
      'userEmail': userEmail,
      'bookId': bookId,
      'bookTitle': bookTitle,
      'issueDate': Timestamp.fromDate(issueDate),
      'dueDate': Timestamp.fromDate(dueDate),
      'status': status,
      'fine': fine,
      'returnedAt': returnedAt != null ? Timestamp.fromDate(returnedAt!) : null,
    };
  }
}
