import 'package:cloud_firestore/cloud_firestore.dart';

class BookRequestModel {
  final String id;
  final String userId;
  final String userName;
  final String userEmail;
  final String title;
  final String author;
  final String message;
  final String status; // 'Open', 'Approved', 'Rejected', 'Completed'
  final DateTime createdAt;

  BookRequestModel({
    required this.id,
    required this.userId,
    required this.userName,
    required this.userEmail,
    required this.title,
    this.author = '',
    required this.message,
    this.status = 'Open',
    required this.createdAt,
  });

  factory BookRequestModel.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>? ?? {};
    return BookRequestModel(
      id: doc.id,
      userId: data['userId'] as String? ?? '',
      userName: data['userName'] as String? ?? '',
      userEmail: data['userEmail'] as String? ?? '',
      title: data['title'] as String? ?? '',
      author: data['author'] as String? ?? '',
      message: data['message'] as String? ?? '',
      status: data['status'] as String? ?? 'Open',
      createdAt: data['createdAt'] is Timestamp
          ? (data['createdAt'] as Timestamp).toDate()
          : DateTime.now(),
    );
  }

  Map<String, dynamic> toFirestore() {
    return {
      'userId': userId,
      'userName': userName,
      'userEmail': userEmail,
      'title': title,
      'author': author,
      'message': message,
      'status': status,
      'createdAt': Timestamp.fromDate(createdAt),
    };
  }
}
