import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/issue_model.dart';

class IssueService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  CollectionReference get _issuesRef => _firestore.collection('issues');
  CollectionReference get _booksRef => _firestore.collection('books');

  /// Issue a book using a Firestore Transaction to guarantee atomic availability update
  Future<String> issueBook({
    required String userId,
    required String userName,
    required String userEmail,
    required String bookId,
    required String bookTitle,
  }) async {
    return await _firestore.runTransaction<String>((transaction) async {
      final bookDocRef = _booksRef.doc(bookId);
      final bookSnapshot = await transaction.get(bookDocRef);

      if (!bookSnapshot.exists) {
        throw Exception('Book not found in library catalog.');
      }

      final bookData = bookSnapshot.data() as Map<String, dynamic>? ?? {};
      final currentAvailable = (bookData['available'] as num?)?.toInt() ?? 0;

      if (currentAvailable <= 0) {
        throw Exception('No copies currently available to issue.');
      }

      // Decrement available copies
      transaction.update(bookDocRef, {
        'available': currentAvailable - 1,
      });

      final newIssueRef = _issuesRef.doc();
      final now = DateTime.now();
      final dueDate = now.add(const Duration(days: 14));

      final issueData = {
        'userId': userId,
        'userName': userName,
        'userEmail': userEmail,
        'bookId': bookId,
        'bookTitle': bookTitle,
        'issueDate': Timestamp.fromDate(now),
        'dueDate': Timestamp.fromDate(dueDate),
        'status': 'Active',
        'fine': 0,
        'returnedAt': null,
      };

      transaction.set(newIssueRef, issueData);
      return newIssueRef.id;
    });
  }

  /// Return an issued book using a Firestore Transaction
  Future<void> returnBook({
    required String issueId,
    required String bookId,
  }) async {
    await _firestore.runTransaction((transaction) async {
      final issueDocRef = _issuesRef.doc(issueId);
      final issueSnapshot = await transaction.get(issueDocRef);

      if (!issueSnapshot.exists) {
        throw Exception('Issue record not found.');
      }

      final issue = IssueModel.fromFirestore(issueSnapshot);
      if (issue.status == 'Returned') {
        throw Exception('This book has already been returned.');
      }

      final bookDocRef = _booksRef.doc(bookId);
      final bookSnapshot = await transaction.get(bookDocRef);

      if (bookSnapshot.exists) {
        final bookData = bookSnapshot.data() as Map<String, dynamic>? ?? {};
        final currentAvailable = (bookData['available'] as num?)?.toInt() ?? 0;
        final totalQuantity = (bookData['quantity'] as num?)?.toInt() ?? currentAvailable + 1;

        // Restore available count (capped at quantity)
        final newAvailable = (currentAvailable + 1).clamp(0, totalQuantity);
        transaction.update(bookDocRef, {'available': newAvailable});
      }

      final now = DateTime.now();
      // Calculate final fine if overdue (৳5/day)
      int finalFine = 0;
      if (now.isAfter(issue.dueDate)) {
        final days = now.difference(issue.dueDate).inDays;
        finalFine = (days > 0 ? days : 1) * 5;
      }

      transaction.update(issueDocRef, {
        'status': 'Returned',
        'fine': finalFine,
        'returnedAt': Timestamp.fromDate(now),
      });
    });
  }

  /// Stream active or all issues for a specific student
  Stream<List<IssueModel>> streamUserIssues(String userId) {
    return _issuesRef
        .where('userId', isEqualTo: userId)
        .snapshots()
        .map((snapshot) {
      final issues = snapshot.docs.map((doc) => IssueModel.fromFirestore(doc)).toList();
      // Sort: Active first, then by dueDate ascending
      issues.sort((a, b) {
        if (a.status == 'Active' && b.status != 'Active') return -1;
        if (a.status != 'Active' && b.status == 'Active') return 1;
        return a.dueDate.compareTo(b.dueDate);
      });
      return issues;
    });
  }

  /// Stream all issues for Admin dashboard
  Stream<List<IssueModel>> streamAllIssues() {
    return _issuesRef.snapshots().map((snapshot) {
      final issues = snapshot.docs.map((doc) => IssueModel.fromFirestore(doc)).toList();
      issues.sort((a, b) => b.issueDate.compareTo(a.issueDate));
      return issues;
    });
  }
}
