import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/request_model.dart';

class RequestService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  CollectionReference get _requestsRef => _firestore.collection('requests');

  /// Create a new book request
  Future<String> createRequest({
    required String userId,
    required String userName,
    required String userEmail,
    required String title,
    String author = '',
    required String message,
  }) async {
    final docRef = await _requestsRef.add({
      'userId': userId,
      'userName': userName,
      'userEmail': userEmail,
      'title': title.trim(),
      'author': author.trim(),
      'message': message.trim(),
      'status': 'Open',
      'createdAt': FieldValue.serverTimestamp(),
    });
    return docRef.id;
  }

  /// Stream open requests for student community feed
  Stream<List<BookRequestModel>> streamOpenRequests() {
    return _requestsRef
        .where('status', isEqualTo: 'Open')
        .snapshots()
        .map((snapshot) {
      final list = snapshot.docs.map((doc) => BookRequestModel.fromFirestore(doc)).toList();
      list.sort((a, b) => b.createdAt.compareTo(a.createdAt));
      return list;
    });
  }

  /// Stream requests submitted by a specific student
  Stream<List<BookRequestModel>> streamUserRequests(String userId) {
    return _requestsRef
        .where('userId', isEqualTo: userId)
        .snapshots()
        .map((snapshot) {
      final list = snapshot.docs.map((doc) => BookRequestModel.fromFirestore(doc)).toList();
      list.sort((a, b) => b.createdAt.compareTo(a.createdAt));
      return list;
    });
  }

  /// Stream all requests for Admin
  Stream<List<BookRequestModel>> streamAllRequests() {
    return _requestsRef.snapshots().map((snapshot) {
      final list = snapshot.docs.map((doc) => BookRequestModel.fromFirestore(doc)).toList();
      list.sort((a, b) => b.createdAt.compareTo(a.createdAt));
      return list;
    });
  }

  /// Update request status (Admin)
  Future<void> updateRequestStatus(String requestId, String status) async {
    await _requestsRef.doc(requestId).update({'status': status});
  }
}
