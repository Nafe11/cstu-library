import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/message_model.dart';

class MessageService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  CollectionReference get _conversationsRef => _firestore.collection('conversations');

  /// Generate a deterministic conversation ID between two students
  String getConversationId(String uid1, String uid2, [String? topic]) {
    final sorted = [uid1, uid2]..sort();
    if (topic != null && topic.isNotEmpty) {
      // Clean topic string for doc id
      final safeTopic = topic.replaceAll(RegExp(r'[^a-zA-Z0-9]'), '_').toLowerCase();
      return '${sorted[0]}_${sorted[1]}_$safeTopic';
    }
    return '${sorted[0]}_${sorted[1]}';
  }

  /// Get or create conversation between two students
  Future<ConversationModel> getOrCreateConversation({
    required String currentUserId,
    required String currentUserName,
    required String targetUserId,
    required String targetUserName,
    String? bookTitle,
  }) async {
    final convId = getConversationId(currentUserId, targetUserId, bookTitle);
    final docRef = _conversationsRef.doc(convId);
    final doc = await docRef.get();

    if (doc.exists && doc.data() != null) {
      return ConversationModel.fromFirestore(doc);
    }

    final initialData = {
      'participants': [currentUserId, targetUserId],
      'participantNames': {
        currentUserId: currentUserName,
        targetUserId: targetUserName,
      },
      'lastMessage': bookTitle != null ? 'Inquiry regarding: $bookTitle' : 'Conversation started',
      'lastSenderId': currentUserId,
      'lastMessageTime': FieldValue.serverTimestamp(),
      'bookTitle': bookTitle,
    };

    await docRef.set(initialData);

    return ConversationModel(
      id: convId,
      participants: [currentUserId, targetUserId],
      participantNames: {
        currentUserId: currentUserName,
        targetUserId: targetUserName,
      },
      lastMessage: initialData['lastMessage'] as String,
      lastSenderId: currentUserId,
      lastMessageTime: DateTime.now(),
      bookTitle: bookTitle,
    );
  }

  /// Stream student's conversations
  Stream<List<ConversationModel>> streamConversations(String userId) {
    return _conversationsRef
        .where('participants', arrayContains: userId)
        .snapshots()
        .map((snapshot) {
      final list = snapshot.docs.map((doc) => ConversationModel.fromFirestore(doc)).toList();
      list.sort((a, b) => b.lastMessageTime.compareTo(a.lastMessageTime));
      return list;
    });
  }

  /// Stream messages in a conversation
  Stream<List<ChatMessageModel>> streamMessages(String conversationId) {
    return _conversationsRef
        .doc(conversationId)
        .collection('messages')
        .snapshots()
        .map((snapshot) {
      final list = snapshot.docs.map((doc) => ChatMessageModel.fromFirestore(doc)).toList();
      list.sort((a, b) => a.timestamp.compareTo(b.timestamp));
      return list;
    });
  }

  /// Send message
  Future<void> sendMessage({
    required String conversationId,
    required String senderId,
    required String senderName,
    required String text,
  }) async {
    final trimmed = text.trim();
    if (trimmed.isEmpty) return;

    final batch = _firestore.batch();
    final convDoc = _conversationsRef.doc(conversationId);
    final msgDoc = convDoc.collection('messages').doc();

    batch.set(msgDoc, {
      'senderId': senderId,
      'senderName': senderName,
      'text': trimmed,
      'timestamp': FieldValue.serverTimestamp(),
    });

    batch.update(convDoc, {
      'lastMessage': trimmed,
      'lastSenderId': senderId,
      'lastMessageTime': FieldValue.serverTimestamp(),
    });

    await batch.commit();
  }
}
