import 'package:cloud_firestore/cloud_firestore.dart';

import '../models/book_model.dart';

class BookService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  CollectionReference get _booksRef => _firestore.collection('books');

  /// Stream books filtered by university department
  Stream<List<BookModel>> streamBooksByDepartment(String department) {
    return _booksRef
        .where('department', isEqualTo: department)
        .snapshots()
        .map(
          (snapshot) =>
              snapshot.docs.map((doc) => BookModel.fromFirestore(doc)).toList(),
        );
  }

  /// Stream all books (e.g. for Admin, Search, Catalog)
  Stream<List<BookModel>> streamAllBooks() {
    return _booksRef.snapshots().map(
      (snapshot) =>
          snapshot.docs.map((doc) => BookModel.fromFirestore(doc)).toList(),
    );
  }

  /// Get single book
  Future<BookModel?> getBook(String id) async {
    final doc = await _booksRef.doc(id).get();
    if (!doc.exists) return null;
    return BookModel.fromFirestore(doc);
  }

  /// Add new book (Admin)
  Future<String> addBook(BookModel book) async {
    final docRef = await _booksRef.add(book.toFirestore());
    return docRef.id;
  }

  /// Update book (Admin)
  Future<void> updateBook(BookModel book) async {
    await _booksRef.doc(book.id).update(book.toFirestore());
  }

  /// Delete book (Admin)
  Future<void> deleteBook(String id) async {
    await _booksRef.doc(id).delete();
  }

  /// Seed initial CSTU sample library books if collection is empty
  Future<void> seedInitialBooksIfEmpty() async {
    try {
      final snapshot = await _booksRef.limit(1).get();
      if (snapshot.docs.isNotEmpty) return; // Already has books

      final List<Map<String, dynamic>> sampleBooks = [
        {
          'title': 'Database System Concepts',
          'author': 'Abraham Silberschatz',
          'isbn': '978-0078022159',
          'department': 'CSE',
          'shelf': 'CSE-A1',
          'quantity': 5,
          'available': 4,
          'description': 'Comprehensive textbook covering database design, relational model, SQL, transactions, and indexing.',
        },
        {
          'title': 'Introduction to Algorithms',
          'author': 'Thomas H. Cormen, Charles E. Leiserson',
          'isbn': '978-0262033848',
          'department': 'CSE',
          'shelf': 'CSE-A2',
          'quantity': 6,
          'available': 5,
          'description': 'The definitive textbook on algorithms, data structures, dynamic programming, and graph theory.',
        },
        {
          'title': 'Computer Networking: A Top-Down Approach',
          'author': 'James Kurose, Keith Ross',
          'isbn': '978-0133594140',
          'department': 'CSE',
          'shelf': 'CSE-B1',
          'quantity': 4,
          'available': 3,
          'description': 'Covers the internet protocol stack from application down to physical layer with modern examples.',
        },
        {
          'title': 'Fundamentals of Electric Circuits',
          'author': 'Charles Alexander, Matthew Sadiku',
          'isbn': '978-0078028229',
          'department': 'EEE',
          'shelf': 'EEE-A1',
          'quantity': 5,
          'available': 3,
          'description': 'Standard circuit analysis textbook covering Ohm\'s Law, Kirchhoff\'s Laws, AC/DC analysis, and transformers.',
        },
        {
          'title': 'Microelectronic Circuits',
          'author': 'Adel S. Sedra, Kenneth C. Smith',
          'isbn': '978-0199339136',
          'department': 'EEE',
          'shelf': 'EEE-B2',
          'quantity': 4,
          'available': 2,
          'description': 'Authoritative guide to semiconductor physics, diodes, BJTs, MOSFETs, and amplifier design.',
        },
        {
          'title': 'Structural Analysis',
          'author': 'Russell C. Hibbeler',
          'isbn': '978-0134610672',
          'department': 'Civil Engineering',
          'shelf': 'CE-01',
          'quantity': 4,
          'available': 3,
          'description': 'Classical and matrix methods for structural analysis of beams, trusses, and rigid frames.',
        },
        {
          'title': 'Principles of Management',
          'author': 'Harold Koontz, Heinz Weihrich',
          'isbn': '978-0070356054',
          'department': 'BBA',
          'shelf': 'BBA-03',
          'quantity': 4,
          'available': 4,
          'description': 'Fundamentals of modern organizational management, planning, leadership, and operational control.',
        },
        {
          'title': 'Oxford Practice Grammar with Answers',
          'author': 'John Eastwood',
          'isbn': '978-0194579681',
          'department': 'English',
          'shelf': 'ENG-01',
          'quantity': 5,
          'available': 4,
          'description': 'In-depth reference and practice for English grammar, syntax, and advanced academic writing.',
        },
        {
          'title': 'Calculus: Early Transcendentals',
          'author': 'James Stewart',
          'isbn': '978-1285741550',
          'department': 'Mathematics',
          'shelf': 'MATH-02',
          'quantity': 6,
          'available': 5,
          'description': 'Covers limits, single and multivariable calculus, vectors, and differential equations.',
        },
        {
          'title': 'University Physics with Modern Physics',
          'author': 'Hugh D. Young, Roger A. Freedman',
          'isbn': '978-0135159553',
          'department': 'Physics',
          'shelf': 'PHY-01',
          'quantity': 5,
          'available': 4,
          'description': 'Comprehensive calculus-based physics covering mechanics, waves, electromagnetism, and optics.',
        },
        {
          'title': 'General Chemistry: Principles and Modern Applications',
          'author': 'Ralph H. Petrucci',
          'isbn': '978-0132931281',
          'department': 'Chemistry',
          'shelf': 'CHEM-01',
          'quantity': 4,
          'available': 3,
          'description': 'Essential chemistry concepts including atomic theory, chemical equilibrium, thermochemistry, and kinetics.',
        },
      ];

      final batch = _firestore.batch();
      for (final book in sampleBooks) {
        final docRef = _booksRef.doc();
        batch.set(docRef, {...book, 'createdAt': FieldValue.serverTimestamp()});
      }
      await batch.commit();
    } catch (_) {
      // Ignore if seeding fails due to permissions or existing records
    }
  }
}
