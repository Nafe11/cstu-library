import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../models/issue_model.dart';
import '../../models/user_model.dart';
import '../../services/issue_service.dart';
import '../../widgets/empty_state.dart';

class MyBooksScreen extends StatefulWidget {
  final UserModel currentUser;
  final bool showAppBar;

  const MyBooksScreen({
    super.key,
    required this.currentUser,
    this.showAppBar = true,
  });

  @override
  State<MyBooksScreen> createState() => _MyBooksScreenState();
}

class _MyBooksScreenState extends State<MyBooksScreen> {
  final _issueService = IssueService();
  final _dateFormat = DateFormat('dd MMM yyyy');

  Future<void> _handleReturnBook(IssueModel issue) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Return Book'),
        content: Text(
          'Confirm return for "${issue.bookTitle}"?${issue.fine > 0 ? '\n\nOutstanding late fine: ৳${issue.fine}' : ''}',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF0D47A1),
              foregroundColor: Colors.white,
            ),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Confirm Return'),
          ),
        ],
      ),
    );

    if (confirmed != true) return;

    try {
      await _issueService.returnBook(
        issueId: issue.id,
        bookId: issue.bookId,
      );

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Returned "${issue.bookTitle}". Available copies updated!'),
          backgroundColor: Colors.green.shade700,
        ),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(e.toString().replaceAll('Exception: ', '')),
          backgroundColor: Colors.red.shade700,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8FAFC),
      appBar: widget.showAppBar
          ? AppBar(
              title: const Text('My Issued Books'),
              backgroundColor: Colors.white,
              foregroundColor: const Color(0xFF0D47A1),
              elevation: 0,
            )
          : null,
      body: StreamBuilder<List<IssueModel>>(
        stream: _issueService.streamUserIssues(widget.currentUser.uid),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          }

          final issues = snapshot.data ?? [];

          if (issues.isEmpty) {
            return const EmptyState(
              icon: Icons.book_outlined,
              title: 'No Borrowed Books',
              message: 'You currently have no issued books. Browse the catalog to borrow.',
            );
          }

          return ListView.builder(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            itemCount: issues.length,
            itemBuilder: (context, index) {
              final issue = issues[index];
              final isOverdue = issue.isOverdue;
              final isReturned = issue.status == 'Returned';

              return Card(
                elevation: 0,
                margin: const EdgeInsets.symmetric(vertical: 6),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                  side: BorderSide(
                    color: isOverdue && !isReturned
                        ? const Color(0xFFEF4444).withValues(alpha: 0.4)
                        : Colors.grey.shade200,
                  ),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Header Row: Title & Status Badge
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(
                            child: Text(
                              issue.bookTitle,
                              style: const TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                                color: Color(0xFF1E293B),
                              ),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                            decoration: BoxDecoration(
                              color: isReturned
                                  ? Colors.grey.shade200
                                  : isOverdue
                                      ? const Color(0xFFFFEBEE)
                                      : const Color(0xFFE8F5E9),
                              borderRadius: BorderRadius.circular(6),
                            ),
                            child: Text(
                              issue.displayStatus,
                              style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.bold,
                                color: isReturned
                                    ? Colors.grey.shade700
                                    : isOverdue
                                        ? const Color(0xFFC62828)
                                        : const Color(0xFF2E7D32),
                              ),
                            ),
                          ),
                        ],
                      ),
                      const Divider(height: 20),

                      // Dates and Fine
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Issue Date',
                                style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
                              ),
                              const SizedBox(height: 2),
                              Text(
                                _dateFormat.format(issue.issueDate),
                                style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
                              ),
                            ],
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'Due Date',
                                style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
                              ),
                              const SizedBox(height: 2),
                              Text(
                                _dateFormat.format(issue.dueDate),
                                style: TextStyle(
                                  fontSize: 13,
                                  fontWeight: FontWeight.w600,
                                  color: isOverdue && !isReturned
                                      ? const Color(0xFFC62828)
                                      : const Color(0xFF1E293B),
                                ),
                              ),
                            ],
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              Text(
                                'Fine (৳5/day)',
                                style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
                              ),
                              const SizedBox(height: 2),
                              Text(
                                '৳${issue.fine}',
                                style: TextStyle(
                                  fontSize: 14,
                                  fontWeight: FontWeight.bold,
                                  color: issue.fine > 0
                                      ? const Color(0xFFC62828)
                                      : Colors.grey.shade700,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),

                      if (!isReturned) ...[
                        const SizedBox(height: 12),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            OutlinedButton.icon(
                              onPressed: () => _handleReturnBook(issue),
                              icon: const Icon(Icons.assignment_return_outlined, size: 16),
                              label: const Text('Return Book', style: TextStyle(fontSize: 13)),
                              style: OutlinedButton.styleFrom(
                                foregroundColor: const Color(0xFF0D47A1),
                                visualDensity: VisualDensity.compact,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(6),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
