import 'package:flutter/material.dart';
import '../../models/book_model.dart';
import '../../services/book_service.dart';

class AdminBookFormScreen extends StatefulWidget {
  final BookModel? bookToEdit;

  const AdminBookFormScreen({super.key, this.bookToEdit});

  @override
  State<AdminBookFormScreen> createState() => _AdminBookFormScreenState();
}

class _AdminBookFormScreenState extends State<AdminBookFormScreen> {
  final _bookService = BookService();
  final _formKey = GlobalKey<FormState>();

  late TextEditingController _titleController;
  late TextEditingController _authorController;
  late TextEditingController _isbnController;
  late TextEditingController _shelfController;
  late TextEditingController _quantityController;
  late TextEditingController _descriptionController;

  late String _selectedDepartment;
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    final b = widget.bookToEdit;
    _titleController = TextEditingController(text: b?.title ?? '');
    _authorController = TextEditingController(text: b?.author ?? '');
    _isbnController = TextEditingController(text: b?.isbn ?? '');
    _shelfController = TextEditingController(text: b?.shelf ?? '');
    _quantityController = TextEditingController(text: b != null ? '${b.quantity}' : '1');
    _descriptionController = TextEditingController(text: b?.description ?? '');
    _selectedDepartment = b?.department ?? UniversityDepartments.list.first;
  }

  @override
  void dispose() {
    _titleController.dispose();
    _authorController.dispose();
    _isbnController.dispose();
    _shelfController.dispose();
    _quantityController.dispose();
    _descriptionController.dispose();
    super.dispose();
  }

  Future<void> _handleSave() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _isLoading = true);

    try {
      final qty = int.tryParse(_quantityController.text.trim()) ?? 1;

      if (widget.bookToEdit != null) {
        // Edit existing book
        final original = widget.bookToEdit!;
        // Adjust available count if quantity changed
        final diff = qty - original.quantity;
        final newAvailable = (original.available + diff).clamp(0, qty);

        final updated = BookModel(
          id: original.id,
          title: _titleController.text.trim(),
          author: _authorController.text.trim(),
          isbn: _isbnController.text.trim(),
          department: _selectedDepartment,
          shelf: _shelfController.text.trim(),
          quantity: qty,
          available: newAvailable,
          description: _descriptionController.text.trim(),
          createdAt: original.createdAt,
        );

        await _bookService.updateBook(updated);

        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Book updated successfully!'), backgroundColor: Colors.green),
        );
      } else {
        // Add new book
        final newBook = BookModel(
          id: '',
          title: _titleController.text.trim(),
          author: _authorController.text.trim(),
          isbn: _isbnController.text.trim(),
          department: _selectedDepartment,
          shelf: _shelfController.text.trim(),
          quantity: qty,
          available: qty,
          description: _descriptionController.text.trim(),
          createdAt: DateTime.now(),
        );

        await _bookService.addBook(newBook);

        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Book added to library!'), backgroundColor: Colors.green),
        );
      }

      Navigator.of(context).pop();
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e'), backgroundColor: Colors.red),
      );
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final isEditing = widget.bookToEdit != null;

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: Text(isEditing ? 'Edit Book' : 'Add New Book'),
        backgroundColor: Colors.white,
        foregroundColor: const Color(0xFF0D47A1),
        elevation: 0,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              TextFormField(
                controller: _titleController,
                decoration: const InputDecoration(
                  labelText: 'Book Title *',
                  border: OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(8))),
                ),
                validator: (val) => val == null || val.trim().isEmpty ? 'Enter book title' : null,
              ),
              const SizedBox(height: 14),
              TextFormField(
                controller: _authorController,
                decoration: const InputDecoration(
                  labelText: 'Author *',
                  border: OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(8))),
                ),
                validator: (val) => val == null || val.trim().isEmpty ? 'Enter author name' : null,
              ),
              const SizedBox(height: 14),
              TextFormField(
                controller: _isbnController,
                decoration: const InputDecoration(
                  labelText: 'ISBN *',
                  border: OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(8))),
                ),
                validator: (val) => val == null || val.trim().isEmpty ? 'Enter ISBN' : null,
              ),
              const SizedBox(height: 14),
              DropdownButtonFormField<String>(
                initialValue: _selectedDepartment,
                decoration: const InputDecoration(
                  labelText: 'Department *',
                  border: OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(8))),
                ),
                items: UniversityDepartments.list
                    .map((d) => DropdownMenuItem(value: d, child: Text(d)))
                    .toList(),
                onChanged: (val) {
                  if (val != null) setState(() => _selectedDepartment = val);
                },
              ),
              const SizedBox(height: 14),
              Row(
                children: [
                  Expanded(
                    child: TextFormField(
                      controller: _shelfController,
                      decoration: const InputDecoration(
                        labelText: 'Shelf Location *',
                        hintText: 'e.g. CSE-A1',
                        border: OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(8))),
                      ),
                      validator: (val) => val == null || val.trim().isEmpty ? 'Enter shelf location' : null,
                    ),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: TextFormField(
                      controller: _quantityController,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(
                        labelText: 'Total Copies *',
                        border: OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(8))),
                      ),
                      validator: (val) {
                        if (val == null || val.trim().isEmpty) return 'Enter quantity';
                        final num = int.tryParse(val.trim());
                        if (num == null || num <= 0) return 'Must be >= 1';
                        return null;
                      },
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 14),
              TextFormField(
                controller: _descriptionController,
                maxLines: 4,
                decoration: const InputDecoration(
                  labelText: 'Description',
                  hintText: 'Brief summary of the textbook...',
                  border: OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(8))),
                ),
              ),
              const SizedBox(height: 28),
              ElevatedButton(
                onPressed: _isLoading ? null : _handleSave,
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF0D47A1),
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                ),
                child: _isLoading
                    ? const SizedBox(
                        width: 20,
                        height: 20,
                        child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2),
                      )
                    : Text(
                        isEditing ? 'Save Changes' : 'Add Book to Catalog',
                        style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                      ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
