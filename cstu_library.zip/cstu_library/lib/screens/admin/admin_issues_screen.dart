import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../models/issue_model.dart';
import '../../services/issue_service.dart';
import '../../widgets/empty_state.dart';

class AdminIssuesScreen extends StatefulWidget {
  const AdminIssuesScreen({super.key});

  @override
  State<AdminIssuesScreen> createState() => _AdminIssuesScreenState();
}

class _AdminIssuesScreenState extends State<AdminIssuesScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final _issueService = IssueService();
  final _dateFormat = DateFormat('dd MMM yyyy');

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  Future<void> _handleReturn(IssueModel issue) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Confirm Return'),
        content: Text(
          'Mark "${issue.bookTitle}" borrowed by ${issue.userName} as returned?${issue.fine > 0 ? '\n\nCollect fine: ৳${issue.fine}' : ''}',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF0D47A1),
              foregroundColor: Colors.white,
            ),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Mark Returned'),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      await _issueService.returnBook(issueId: issue.id, bookId: issue.bookId);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Returned "${issue.bookTitle}"!'), backgroundColor: Colors.green),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8FAFC),
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(48),
        child: Container(
          color: Colors.white,
          child: TabBar(
            controller: _tabController,
            labelColor: const Color(0xFF0D47A1),
            indicatorColor: const Color(0xFF0D47A1),
            tabs: const [
              Tab(text: 'Active Issues'),
              Tab(text: 'Overdue Books'),
            ],
          ),
        ),
      ),
      body: StreamBuilder<List<IssueModel>>(
        stream: _issueService.streamAllIssues(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          final allIssues = snapshot.data ?? [];
          final activeIssues = allIssues.where((i) => i.status == 'Active').toList();
          final overdueIssues = activeIssues.where((i) => i.isOverdue).toList();

          return TabBarView(
            controller: _tabController,
            children: [
              _buildIssuesList(activeIssues, 'No active book borrowings.'),
              _buildIssuesList(overdueIssues, 'Great news! No overdue books currently.'),
            ],
          );
        },
      ),
    );
  }

  Widget _buildIssuesList(List<IssueModel> issues, String emptyMessage) {
    if (issues.isEmpty) {
      return EmptyState(
        icon: Icons.assignment_turned_in_outlined,
        title: 'No Records',
        message: emptyMessage,
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      itemCount: issues.length,
      itemBuilder: (context, index) {
        final issue = issues[index];
        final isOverdue = issue.isOverdue;

        return Card(
          elevation: 0,
          margin: const EdgeInsets.symmetric(vertical: 6),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
            side: BorderSide(
              color: isOverdue ? const Color(0xFFEF4444).withValues(alpha: 0.4) : Colors.grey.shade200,
            ),
          ),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            issue.bookTitle,
                            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            'Student: ${issue.userName} (${issue.userEmail})',
                            style: TextStyle(fontSize: 12, color: Colors.grey.shade700),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                      decoration: BoxDecoration(
                        color: isOverdue ? const Color(0xFFFFEBEE) : const Color(0xFFE8F5E9),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Text(
                        isOverdue ? 'Overdue' : 'Active',
                        style: TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.bold,
                          color: isOverdue ? const Color(0xFFC62828) : const Color(0xFF2E7D32),
                        ),
                      ),
                    ),
                  ],
                ),
                const Divider(height: 20),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Issued: ${_dateFormat.format(issue.issueDate)}',
                            style: TextStyle(fontSize: 11, color: Colors.grey.shade600)),
                        Text('Due: ${_dateFormat.format(issue.dueDate)}',
                            style: TextStyle(
                              fontSize: 11,
                              fontWeight: FontWeight.w600,
                              color: isOverdue ? const Color(0xFFC62828) : Colors.grey.shade800,
                            )),
                      ],
                    ),
                    if (issue.fine > 0)
                      Text(
                        'Fine: ৳${issue.fine}',
                        style: const TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.bold,
                          color: Color(0xFFC62828),
                        ),
                      ),
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF0D47A1),
                        foregroundColor: Colors.white,
                        visualDensity: VisualDensity.compact,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
                      ),
                      onPressed: () => _handleReturn(issue),
                      child: const Text('Mark Returned', style: TextStyle(fontSize: 12)),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
