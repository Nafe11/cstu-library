import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../models/request_model.dart';
import '../../services/notification_service.dart';
import '../../services/request_service.dart';
import '../../widgets/empty_state.dart';

class AdminRequestsScreen extends StatelessWidget {
  const AdminRequestsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final requestService = RequestService();
    final notificationService = NotificationService();
    final dateFormat = DateFormat('dd MMM yyyy, hh:mm a');

    Future<void> updateStatus(BookRequestModel request, String newStatus) async {
      await requestService.updateRequestStatus(request.id, newStatus);
      // Notify student
      await notificationService.sendNotification(
        userId: request.userId,
        title: 'Book Request $newStatus',
        message: 'Your request for "${request.title}" has been updated to $newStatus by CSTU Library Admin.',
        type: 'request_status',
      );

      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Request marked as $newStatus'),
            backgroundColor: Colors.green,
          ),
        );
      }
    }

    return Scaffold(
      backgroundColor: const Color(0xFFF8FAFC),
      body: StreamBuilder<List<BookRequestModel>>(
        stream: requestService.streamAllRequests(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          final requests = snapshot.data ?? [];

          if (requests.isEmpty) {
            return const EmptyState(
              icon: Icons.checklist_rtl_rounded,
              title: 'No Book Requests',
              message: 'No student requests have been submitted.',
            );
          }

          return ListView.builder(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            itemCount: requests.length,
            itemBuilder: (context, index) {
              final req = requests[index];

              Color statusColor;
              Color statusBg;
              switch (req.status) {
                case 'Approved':
                  statusColor = const Color(0xFF2E7D32);
                  statusBg = const Color(0xFFE8F5E9);
                  break;
                case 'Rejected':
                  statusColor = const Color(0xFFC62828);
                  statusBg = const Color(0xFFFFEBEE);
                  break;
                case 'Completed':
                  statusColor = const Color(0xFF1565C0);
                  statusBg = const Color(0xFFE3F2FD);
                  break;
                default:
                  statusColor = const Color(0xFFE65100);
                  statusBg = const Color(0xFFFFF3E0);
              }

              return Card(
                elevation: 0,
                margin: const EdgeInsets.symmetric(vertical: 6),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                  side: BorderSide(color: Colors.grey.shade200),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Expanded(
                            child: Text(
                              req.title,
                              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                            ),
                          ),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                            decoration: BoxDecoration(
                              color: statusBg,
                              borderRadius: BorderRadius.circular(6),
                            ),
                            child: Text(
                              req.status,
                              style: TextStyle(
                                fontSize: 11,
                                fontWeight: FontWeight.bold,
                                color: statusColor,
                              ),
                            ),
                          ),
                        ],
                      ),
                      if (req.author.isNotEmpty) ...[
                        const SizedBox(height: 2),
                        Text('Author: ${req.author}', style: TextStyle(fontSize: 13, color: Colors.grey.shade700)),
                      ],
                      const SizedBox(height: 6),
                      Text('Note: ${req.message}', style: TextStyle(fontSize: 13, color: Colors.grey.shade800)),
                      const Divider(height: 20),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'Student: ${req.userName}',
                                  style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600),
                                ),
                                Text(
                                  dateFormat.format(req.createdAt),
                                  style: TextStyle(fontSize: 11, color: Colors.grey.shade500),
                                ),
                              ],
                            ),
                          ),
                          PopupMenuButton<String>(
                            tooltip: 'Update Status',
                            onSelected: (val) => updateStatus(req, val),
                            child: Container(
                              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                              decoration: BoxDecoration(
                                color: const Color(0xFF0D47A1).withValues(alpha: 0.08),
                                borderRadius: BorderRadius.circular(6),
                              ),
                              child: const Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Text(
                                    'Update',
                                    style: TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.bold,
                                      color: Color(0xFF0D47A1),
                                    ),
                                  ),
                                  SizedBox(width: 4),
                                  Icon(Icons.arrow_drop_down, size: 18, color: Color(0xFF0D47A1)),
                                ],
                              ),
                            ),
                            itemBuilder: (ctx) => [
                              const PopupMenuItem(value: 'Open', child: Text('Mark as Open')),
                              const PopupMenuItem(value: 'Approved', child: Text('Mark as Approved')),
                              const PopupMenuItem(value: 'Completed', child: Text('Mark as Completed')),
                              const PopupMenuItem(value: 'Rejected', child: Text('Mark as Rejected')),
                            ],
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
