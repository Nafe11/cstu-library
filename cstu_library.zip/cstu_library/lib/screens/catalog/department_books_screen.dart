import 'package:flutter/material.dart';
import '../../models/book_model.dart';
import '../../models/user_model.dart';
import '../../services/book_service.dart';
import '../../widgets/book_card.dart';
import '../../widgets/empty_state.dart';
import '../books/book_details_screen.dart';

class DepartmentBooksScreen extends StatelessWidget {
  final String department;
  final UserModel currentUser;

  const DepartmentBooksScreen({
    super.key,
    required this.department,
    required this.currentUser,
  });

  @override
  Widget build(BuildContext context) {
    final bookService = BookService();

    return Scaffold(
      backgroundColor: const Color(0xFFF8FAFC),
      appBar: AppBar(
        title: Text('$department Department'),
        backgroundColor: Colors.white,
        foregroundColor: const Color(0xFF0D47A1),
        elevation: 0,
      ),
      body: StreamBuilder<List<BookModel>>(
        stream: bookService.streamBooksByDepartment(department),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          if (snapshot.hasError) {
            return Center(child: Text('Error loading books: ${snapshot.error}'));
          }

          final books = snapshot.data ?? [];

          if (books.isEmpty) {
            return EmptyState(
              icon: Icons.menu_book,
              title: 'No books found',
              message: 'No textbooks currently registered for $department.',
            );
          }

          return ListView.builder(
            padding: const EdgeInsets.symmetric(vertical: 12),
            itemCount: books.length,
            itemBuilder: (context, index) {
              final book = books[index];
              return BookCard(
                book: book,
                onTap: () {
                  Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (_) => BookDetailsScreen(
                        initialBook: book,
                        currentUser: currentUser,
                      ),
                    ),
                  );
                },
              );
            },
          );
        },
      ),
    );
  }
}
