import 'package:flutter/material.dart';
import '../../models/book_model.dart';
import '../../models/user_model.dart';
import 'department_books_screen.dart';

class CatalogScreen extends StatelessWidget {
  final UserModel currentUser;
  final bool showAppBar;

  const CatalogScreen({
    super.key,
    required this.currentUser,
    this.showAppBar = true,
  });

  IconData _getDepartmentIcon(String dept) {
    switch (dept) {
      case 'CSE':
        return Icons.computer_rounded;
      case 'EEE':
        return Icons.electric_bolt_rounded;
      case 'Civil Engineering':
        return Icons.architecture_rounded;
      case 'BBA':
        return Icons.trending_up_rounded;
      case 'English':
        return Icons.translate_rounded;
      case 'Mathematics':
        return Icons.calculate_rounded;
      case 'Physics':
        return Icons.science_rounded;
      case 'Chemistry':
        return Icons.biotech_rounded;
      default:
        return Icons.school_rounded;
    }
  }

  @override
  Widget build(BuildContext context) {
    final departments = UniversityDepartments.list;

    return Scaffold(
      backgroundColor: const Color(0xFFF8FAFC),
      appBar: showAppBar
          ? AppBar(
              title: const Text('Academic Catalog'),
              backgroundColor: Colors.white,
              foregroundColor: const Color(0xFF0D47A1),
              elevation: 0,
            )
          : null,
      body: ListView.builder(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        itemCount: departments.length,
        itemBuilder: (context, index) {
          final dept = departments[index];
          final icon = _getDepartmentIcon(dept);

          return Card(
            elevation: 0,
            margin: const EdgeInsets.symmetric(vertical: 6),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
              side: BorderSide(color: Colors.grey.shade200),
            ),
            child: ListTile(
              contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              leading: Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: const Color(0xFF0D47A1).withValues(alpha: 0.08),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(
                  icon,
                  color: const Color(0xFF0D47A1),
                ),
              ),
              title: Text(
                dept,
                style: const TextStyle(
                  fontWeight: FontWeight.w600,
                  fontSize: 15,
                  color: Color(0xFF1E293B),
                ),
              ),
              subtitle: Text(
                'Department textbooks & resources',
                style: TextStyle(
                  fontSize: 12,
                  color: Colors.grey.shade600,
                ),
              ),
              trailing: const Icon(
                Icons.chevron_right_rounded,
                color: Colors.grey,
              ),
              onTap: () {
                Navigator.of(context).push(
                  MaterialPageRoute(
                    builder: (_) => DepartmentBooksScreen(
                      department: dept,
                      currentUser: currentUser,
                    ),
                  ),
                );
              },
            ),
          );
        },
      ),
    );
  }
}
