import 'package:flutter/material.dart';
import '../../models/issue_model.dart';
import '../../models/user_model.dart';
import '../../services/issue_service.dart';
import '../inbox/inbox_screen.dart';

class HomeScreen extends StatelessWidget {
  final UserModel currentUser;
  final Function(int index) onNavigateTab;

  const HomeScreen({
    super.key,
    required this.currentUser,
    required this.onNavigateTab,
  });

  @override
  Widget build(BuildContext context) {
    final issueService = IssueService();

    return Scaffold(
      backgroundColor: const Color(0xFFF8FAFC),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Welcome Header Card
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFF0D47A1), Color(0xFF1976D2)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(16),
                boxShadow: [
                  BoxShadow(
                    color: const Color(0xFF0D47A1).withValues(alpha: 0.25),
                    blurRadius: 10,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: Colors.white.withValues(alpha: 0.18),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: const Text(
                          'CSTU Library',
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                      IconButton(
                        tooltip: 'Private Inbox',
                        icon: const Icon(Icons.chat_bubble_outline_rounded, color: Colors.white),
                        onPressed: () {
                          Navigator.of(context).push(
                            MaterialPageRoute(
                              builder: (_) => InboxScreen(currentUser: currentUser),
                            ),
                          );
                        },
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Text(
                    'Welcome, ${currentUser.name}',
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'Department of ${currentUser.department}',
                    style: TextStyle(
                      color: Colors.white.withValues(alpha: 0.85),
                      fontSize: 13,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),

            // Active Borrowing Summary
            StreamBuilder<List<IssueModel>>(
              stream: issueService.streamUserIssues(currentUser.uid),
              builder: (context, snapshot) {
                final issues = snapshot.data ?? [];
                final activeIssues = issues.where((i) => i.status == 'Active').toList();
                final overdueCount = activeIssues.where((i) => i.isOverdue).length;

                return Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: Colors.grey.shade200),
                  ),
                  child: Row(
                    children: [
                      Container(
                        width: 44,
                        height: 44,
                        decoration: BoxDecoration(
                          color: overdueCount > 0
                              ? const Color(0xFFFFEBEE)
                              : const Color(0xFFE8F5E9),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Icon(
                          overdueCount > 0 ? Icons.warning_amber_rounded : Icons.bookmark_added_rounded,
                          color: overdueCount > 0 ? const Color(0xFFC62828) : const Color(0xFF2E7D32),
                        ),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              '${activeIssues.length} Books Currently Borrowed',
                              style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14),
                            ),
                            Text(
                              overdueCount > 0
                                  ? '$overdueCount overdue book(s) — Late fine applies'
                                  : 'Borrowing period: 14 days',
                              style: TextStyle(
                                fontSize: 12,
                                color: overdueCount > 0 ? const Color(0xFFC62828) : Colors.grey.shade600,
                              ),
                            ),
                          ],
                        ),
                      ),
                      TextButton(
                        onPressed: () => onNavigateTab(3), // My Books
                        child: const Text('View'),
                      ),
                    ],
                  ),
                );
              },
            ),
            const SizedBox(height: 24),

            // Quick Access Buttons
            const Text(
              'Quick Access',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: Color(0xFF1E293B),
              ),
            ),
            const SizedBox(height: 12),

            _buildActionCard(
              context: context,
              icon: Icons.menu_book_rounded,
              title: 'Catalog',
              subtitle: 'Browse books by university departments',
              onTap: () => onNavigateTab(1),
            ),
            _buildActionCard(
              context: context,
              icon: Icons.search_rounded,
              title: 'Search Books',
              subtitle: 'Find textbooks by title, author, or ISBN',
              onTap: () => onNavigateTab(2),
            ),
            _buildActionCard(
              context: context,
              icon: Icons.auto_stories_rounded,
              title: 'My Books',
              subtitle: 'Check your active issues, due dates, and fines',
              onTap: () => onNavigateTab(3),
            ),
            _buildActionCard(
              context: context,
              icon: Icons.checklist_rtl_rounded,
              title: 'Book Requests',
              subtitle: 'Request unavailable books or help peer students',
              onTap: () => onNavigateTab(4),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildActionCard({
    required BuildContext context,
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return Card(
      elevation: 0,
      margin: const EdgeInsets.symmetric(vertical: 6),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: BorderSide(color: Colors.grey.shade200),
      ),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        leading: Container(
          width: 44,
          height: 44,
          decoration: BoxDecoration(
            color: const Color(0xFF0D47A1).withValues(alpha: 0.08),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Icon(icon, color: const Color(0xFF0D47A1)),
        ),
        title: Text(
          title,
          style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 15),
        ),
        subtitle: Text(
          subtitle,
          style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
        ),
        trailing: const Icon(Icons.arrow_forward_ios_rounded, size: 16, color: Colors.grey),
        onTap: onTap,
      ),
    );
  }
}
