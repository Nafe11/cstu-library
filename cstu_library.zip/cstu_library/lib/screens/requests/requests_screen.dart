import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../models/request_model.dart';
import '../../models/user_model.dart';
import '../../services/message_service.dart';
import '../../services/notification_service.dart';
import '../../services/request_service.dart';
import '../../widgets/empty_state.dart';
import '../inbox/chat_screen.dart';

class RequestsScreen extends StatefulWidget {
  final UserModel currentUser;
  final String? prefillTitle;
  final String? prefillAuthor;

  final bool showAppBar;

  const RequestsScreen({
    super.key,
    required this.currentUser,
    this.prefillTitle,
    this.prefillAuthor,
    this.showAppBar = true,
  });

  @override
  State<RequestsScreen> createState() => RequestsScreenState();
}

class RequestsScreenState extends State<RequestsScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final _requestService = RequestService();
  final _notificationService = NotificationService();
  final _messageService = MessageService();
  final _dateFormat = DateFormat('dd MMM yyyy');

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);

    // If prefilled from Book Details, automatically open the request form dialog
    if (widget.prefillTitle != null) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        showNewRequestSheet(
          prefillTitle: widget.prefillTitle,
          prefillAuthor: widget.prefillAuthor,
        );
      });
    }
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  void showNewRequestSheet({String? prefillTitle, String? prefillAuthor}) {
    final titleController = TextEditingController(text: prefillTitle ?? '');
    final authorController = TextEditingController(text: prefillAuthor ?? '');
    final messageController = TextEditingController();
    final formKey = GlobalKey<FormState>();
    bool isSubmitting = false;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setModalState) {
          return Padding(
            padding: EdgeInsets.only(
              left: 20,
              right: 20,
              top: 20,
              bottom: MediaQuery.of(ctx).viewInsets.bottom + 20,
            ),
            child: Form(
              key: formKey,
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text(
                          'Request a Book',
                          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                        ),
                        IconButton(
                          icon: const Icon(Icons.close),
                          onPressed: () => Navigator.pop(ctx),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    TextFormField(
                      controller: titleController,
                      decoration: const InputDecoration(
                        labelText: 'Book Title *',
                        border: OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(8))),
                      ),
                      validator: (val) =>
                          val == null || val.trim().isEmpty ? 'Enter book title' : null,
                    ),
                    const SizedBox(height: 12),
                    TextFormField(
                      controller: authorController,
                      decoration: const InputDecoration(
                        labelText: 'Author (optional)',
                        border: OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(8))),
                      ),
                    ),
                    const SizedBox(height: 12),
                    TextFormField(
                      controller: messageController,
                      maxLines: 3,
                      decoration: const InputDecoration(
                        labelText: 'Message / Reason for Request *',
                        hintText: 'e.g., Needed for semester exam or not found in library.',
                        border: OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(8))),
                      ),
                      validator: (val) =>
                          val == null || val.trim().isEmpty ? 'Enter a brief message' : null,
                    ),
                    const SizedBox(height: 16),
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF0D47A1),
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                      ),
                      onPressed: isSubmitting
                          ? null
                          : () async {
                              if (!formKey.currentState!.validate()) return;
                              setModalState(() => isSubmitting = true);

                              try {
                                await _requestService.createRequest(
                                  userId: widget.currentUser.uid,
                                  userName: widget.currentUser.name,
                                  userEmail: widget.currentUser.email,
                                  title: titleController.text,
                                  author: authorController.text,
                                  message: messageController.text,
                                );

                                if (ctx.mounted) Navigator.pop(ctx);

                                if (mounted) {
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    const SnackBar(
                                      content: Text('Book request submitted successfully!'),
                                      backgroundColor: Colors.green,
                                    ),
                                  );
                                }
                              } catch (e) {
                                setModalState(() => isSubmitting = false);
                                if (ctx.mounted) {
                                  ScaffoldMessenger.of(ctx).showSnackBar(
                                    SnackBar(content: Text('Error: $e'), backgroundColor: Colors.red),
                                  );
                                }
                              }
                            },
                      child: isSubmitting
                          ? const SizedBox(
                              width: 20,
                              height: 20,
                              child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2),
                            )
                          : const Text('Send Request', style: TextStyle(fontWeight: FontWeight.w600)),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Future<void> _handleHaveThisBook(BookRequestModel request) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Offer Book to Student'),
        content: Text(
          'Notify ${request.userName} that you have "${request.title}" and open a private chat to coordinate?',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF0D47A1),
              foregroundColor: Colors.white,
            ),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Confirm & Chat'),
          ),
        ],
      ),
    );

    if (confirmed != true) return;

    try {
      // 1. Create or get private conversation
      final conversation = await _messageService.getOrCreateConversation(
        currentUserId: widget.currentUser.uid,
        currentUserName: widget.currentUser.name,
        targetUserId: request.userId,
        targetUserName: request.userName,
        bookTitle: request.title,
      );

      // 2. Send notification to the student who requested the book
      await _notificationService.sendNotification(
        userId: request.userId,
        title: 'Book Offer Available!',
        message: '${widget.currentUser.name} has the book you requested: "${request.title}". Open inbox to coordinate.',
        type: 'book_offer',
        conversationId: conversation.id,
      );

      // 3. Send initial message in conversation
      await _messageService.sendMessage(
        conversationId: conversation.id,
        senderId: widget.currentUser.uid,
        senderName: widget.currentUser.name,
        text: 'Hi ${request.userName}, I saw your request for "${request.title}". I have this copy if you still need it!',
      );

      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Notification sent to ${request.userName}!'),
          backgroundColor: Colors.green,
        ),
      );

      // Navigate directly to private chat
      Navigator.of(context).push(
        MaterialPageRoute(
          builder: (_) => ChatScreen(
            conversation: conversation,
            currentUser: widget.currentUser,
          ),
        ),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e'), backgroundColor: Colors.red),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final tabBarView = TabBarView(
      controller: _tabController,
      children: [
        // Tab 1: Community Requests
        StreamBuilder<List<BookRequestModel>>(
            stream: _requestService.streamOpenRequests(),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const Center(child: CircularProgressIndicator());
              }

              final requests = snapshot.data ?? [];

              if (requests.isEmpty) {
                return const EmptyState(
                  icon: Icons.checklist_rtl_rounded,
                  title: 'No Open Requests',
                  message: 'No fellow students have posted book requests currently.',
                );
              }

              return ListView.builder(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                itemCount: requests.length,
                itemBuilder: (context, index) {
                  final req = requests[index];
                  final isOwnRequest = req.userId == widget.currentUser.uid;

                  return Card(
                    elevation: 0,
                    margin: const EdgeInsets.symmetric(vertical: 6),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                      side: BorderSide(color: Colors.grey.shade200),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      req.title,
                                      style: const TextStyle(
                                        fontSize: 16,
                                        fontWeight: FontWeight.bold,
                                        color: Color(0xFF1E293B),
                                      ),
                                    ),
                                    if (req.author.isNotEmpty) ...[
                                      const SizedBox(height: 2),
                                      Text(
                                        'By ${req.author}',
                                        style: TextStyle(fontSize: 13, color: Colors.grey.shade600),
                                      ),
                                    ],
                                  ],
                                ),
                              ),
                              if (isOwnRequest)
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                                  decoration: BoxDecoration(
                                    color: Colors.blue.shade50,
                                    borderRadius: BorderRadius.circular(6),
                                  ),
                                  child: Text(
                                    'Your Request',
                                    style: TextStyle(
                                      fontSize: 11,
                                      fontWeight: FontWeight.w600,
                                      color: Colors.blue.shade800,
                                    ),
                                  ),
                                ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          Text(
                            req.message,
                            style: TextStyle(fontSize: 13, color: Colors.grey.shade800),
                          ),
                          const Divider(height: 20),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                'By ${req.userName} • ${_dateFormat.format(req.createdAt)}',
                                style: TextStyle(fontSize: 11, color: Colors.grey.shade500),
                              ),
                              if (!isOwnRequest)
                                ElevatedButton.icon(
                                  onPressed: () => _handleHaveThisBook(req),
                                  icon: const Icon(Icons.handshake_outlined, size: 16),
                                  label: const Text('I Have This Book', style: TextStyle(fontSize: 12)),
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: const Color(0xFF0D47A1),
                                    foregroundColor: Colors.white,
                                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                                    visualDensity: VisualDensity.compact,
                                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
                                    elevation: 0,
                                  ),
                                ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  );
                },
              );
            },
          ),

          // Tab 2: My Requests
          StreamBuilder<List<BookRequestModel>>(
            stream: _requestService.streamUserRequests(widget.currentUser.uid),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const Center(child: CircularProgressIndicator());
              }

              final requests = snapshot.data ?? [];

              if (requests.isEmpty) {
                return EmptyState(
                  icon: Icons.note_add_outlined,
                  title: 'No Requests Submitted',
                  message: 'Need a book that is unavailable? Press "Request a Book" below.',
                  action: ElevatedButton(
                    onPressed: () => showNewRequestSheet(),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF0D47A1),
                      foregroundColor: Colors.white,
                    ),
                    child: const Text('Request a Book'),
                  ),
                );
              }

              return ListView.builder(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                itemCount: requests.length,
                itemBuilder: (context, index) {
                  final req = requests[index];
                  Color statusColor;
                  Color statusBg;

                  switch (req.status) {
                    case 'Approved':
                      statusColor = const Color(0xFF2E7D32);
                      statusBg = const Color(0xFFE8F5E9);
                      break;
                    case 'Rejected':
                      statusColor = const Color(0xFFC62828);
                      statusBg = const Color(0xFFFFEBEE);
                      break;
                    case 'Completed':
                      statusColor = const Color(0xFF1565C0);
                      statusBg = const Color(0xFFE3F2FD);
                      break;
                    default:
                      statusColor = const Color(0xFFE65100);
                      statusBg = const Color(0xFFFFF3E0);
                  }

                  return Card(
                    elevation: 0,
                    margin: const EdgeInsets.symmetric(vertical: 6),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                      side: BorderSide(color: Colors.grey.shade200),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Expanded(
                                child: Text(
                                  req.title,
                                  style: const TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                    color: Color(0xFF1E293B),
                                  ),
                                ),
                              ),
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                decoration: BoxDecoration(
                                  color: statusBg,
                                  borderRadius: BorderRadius.circular(6),
                                ),
                                child: Text(
                                  req.status,
                                  style: TextStyle(
                                    fontSize: 11,
                                    fontWeight: FontWeight.bold,
                                    color: statusColor,
                                  ),
                                ),
                              ),
                            ],
                          ),
                          if (req.author.isNotEmpty) ...[
                            const SizedBox(height: 2),
                            Text('Author: ${req.author}', style: TextStyle(fontSize: 13, color: Colors.grey.shade600)),
                          ],
                          const SizedBox(height: 6),
                          Text(req.message, style: TextStyle(fontSize: 13, color: Colors.grey.shade800)),
                          const Divider(height: 18),
                          Text(
                            'Submitted: ${_dateFormat.format(req.createdAt)}',
                            style: TextStyle(fontSize: 11, color: Colors.grey.shade500),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              );
            },
          ),
        ],
      );

    if (!widget.showAppBar) {
      return Column(
        children: [
          Container(
            color: Colors.white,
            child: TabBar(
              controller: _tabController,
              labelColor: const Color(0xFF0D47A1),
              indicatorColor: const Color(0xFF0D47A1),
              tabs: const [
                Tab(text: 'Community Requests'),
                Tab(text: 'My Requests'),
              ],
            ),
          ),
          Expanded(child: tabBarView),
        ],
      );
    }

    return Scaffold(
      backgroundColor: const Color(0xFFF8FAFC),
      appBar: AppBar(
        title: const Text('Book Requests'),
        backgroundColor: Colors.white,
        foregroundColor: const Color(0xFF0D47A1),
        elevation: 0,
        bottom: TabBar(
          controller: _tabController,
          labelColor: const Color(0xFF0D47A1),
          indicatorColor: const Color(0xFF0D47A1),
          tabs: const [
            Tab(text: 'Community Requests'),
            Tab(text: 'My Requests'),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => showNewRequestSheet(),
        backgroundColor: const Color(0xFF0D47A1),
        foregroundColor: Colors.white,
        icon: const Icon(Icons.add_comment_rounded),
        label: const Text('Request a Book'),
      ),
      body: tabBarView,
    );
  }
}
