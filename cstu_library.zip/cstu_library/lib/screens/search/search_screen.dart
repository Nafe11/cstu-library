import 'package:flutter/material.dart';
import '../../models/book_model.dart';
import '../../models/user_model.dart';
import '../../services/book_service.dart';
import '../../widgets/book_card.dart';
import '../../widgets/empty_state.dart';
import '../books/book_details_screen.dart';

class SearchScreen extends StatefulWidget {
  final UserModel currentUser;
  final bool showAppBar;

  const SearchScreen({
    super.key,
    required this.currentUser,
    this.showAppBar = true,
  });

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final _bookService = BookService();
  final _searchController = TextEditingController();
  String _searchQuery = '';

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF8FAFC),
      appBar: widget.showAppBar
          ? AppBar(
              title: const Text('Search Books'),
              backgroundColor: Colors.white,
              foregroundColor: const Color(0xFF0D47A1),
              elevation: 0,
            )
          : null,
      body: Column(
        children: [
          // Simple Search Bar
          Container(
            color: Colors.white,
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
            child: TextField(
              controller: _searchController,
              autofocus: false,
              onChanged: (val) {
                setState(() => _searchQuery = val.trim().toLowerCase());
              },
              decoration: InputDecoration(
                hintText: 'Search by Title, Author, or ISBN...',
                prefixIcon: const Icon(Icons.search, color: Color(0xFF0D47A1)),
                suffixIcon: _searchQuery.isNotEmpty
                    ? IconButton(
                        icon: const Icon(Icons.clear, color: Colors.grey),
                        onPressed: () {
                          _searchController.clear();
                          setState(() => _searchQuery = '');
                        },
                      )
                    : null,
                filled: true,
                fillColor: const Color(0xFFF1F5F9),
                contentPadding: const EdgeInsets.symmetric(vertical: 0, horizontal: 16),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
          ),

          // Search Results
          Expanded(
            child: StreamBuilder<List<BookModel>>(
              stream: _bookService.streamAllBooks(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return const Center(child: CircularProgressIndicator());
                }

                if (snapshot.hasError) {
                  return Center(child: Text('Error loading books: ${snapshot.error}'));
                }

                final allBooks = snapshot.data ?? [];

                final filtered = _searchQuery.isEmpty
                    ? allBooks
                    : allBooks.where((book) {
                        final title = book.title.toLowerCase();
                        final author = book.author.toLowerCase();
                        final isbn = book.isbn.toLowerCase();
                        return title.contains(_searchQuery) ||
                            author.contains(_searchQuery) ||
                            isbn.contains(_searchQuery);
                      }).toList();

                if (filtered.isEmpty) {
                  return EmptyState(
                    icon: Icons.search_off,
                    title: 'No matching books found',
                    message: _searchQuery.isEmpty
                        ? 'Library catalog is currently empty.'
                        : 'Try searching with a different title, author, or ISBN.',
                  );
                }

                return ListView.builder(
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  itemCount: filtered.length,
                  itemBuilder: (context, index) {
                    final book = filtered[index];
                    return BookCard(
                      book: book,
                      onTap: () {
                        Navigator.of(context).push(
                          MaterialPageRoute(
                            builder: (_) => BookDetailsScreen(
                              initialBook: book,
                              currentUser: widget.currentUser,
                            ),
                          ),
                        );
                      },
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
