import 'package:flutter/material.dart';
import '../../models/book_model.dart';
import '../../models/user_model.dart';
import '../../services/book_service.dart';
import '../../services/issue_service.dart';
import '../../services/notification_service.dart';
import '../requests/requests_screen.dart';

class BookDetailsScreen extends StatefulWidget {
  final BookModel initialBook;
  final UserModel currentUser;

  const BookDetailsScreen({
    super.key,
    required this.initialBook,
    required this.currentUser,
  });

  @override
  State<BookDetailsScreen> createState() => _BookDetailsScreenState();
}

class _BookDetailsScreenState extends State<BookDetailsScreen> {
  final _bookService = BookService();
  final _issueService = IssueService();
  final _notificationService = NotificationService();

  late BookModel _book;
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    _book = widget.initialBook;
    _refreshBookData();
  }

  Future<void> _refreshBookData() async {
    final updated = await _bookService.getBook(_book.id);
    if (updated != null && mounted) {
      setState(() => _book = updated);
    }
  }

  Future<void> _handleIssueBook() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Confirm Book Issue'),
        content: Text(
          'Do you want to borrow "${_book.title}" for 14 days?\n\nPlease return by the due date to avoid late fines (৳5/day).',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF0D47A1),
              foregroundColor: Colors.white,
            ),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Confirm Issue'),
          ),
        ],
      ),
    );

    if (confirmed != true) return;

    setState(() => _isLoading = true);

    try {
      await _issueService.issueBook(
        userId: widget.currentUser.uid,
        userName: widget.currentUser.name,
        userEmail: widget.currentUser.email,
        bookId: _book.id,
        bookTitle: _book.title,
      );

      // Send local notification
      await _notificationService.sendNotification(
        userId: widget.currentUser.uid,
        title: 'Book Issued Successfully',
        message: 'You have issued "${_book.title}". Return within 14 days.',
        type: 'due_reminder',
      );

      await _refreshBookData();

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Successfully issued "${_book.title}"! Due in 14 days.'),
          backgroundColor: Colors.green.shade700,
        ),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(e.toString().replaceAll('Exception: ', '')),
          backgroundColor: Colors.red.shade700,
        ),
      );
    } finally {
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }
  }

  void _handleRequestBook() {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => RequestsScreen(
          currentUser: widget.currentUser,
          prefillTitle: _book.title,
          prefillAuthor: _book.author,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isAvailable = _book.available > 0;

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text('Book Details'),
        backgroundColor: Colors.white,
        foregroundColor: const Color(0xFF0D47A1),
        elevation: 0,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Book Header Card
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: const Color(0xFF0D47A1).withValues(alpha: 0.05),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: const Color(0xFF0D47A1).withValues(alpha: 0.15)),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: 60,
                    height: 80,
                    decoration: BoxDecoration(
                      color: const Color(0xFF0D47A1).withValues(alpha: 0.12),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: const Icon(
                      Icons.book_rounded,
                      size: 36,
                      color: Color(0xFF0D47A1),
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          _book.title,
                          style: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: Color(0xFF1E293B),
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          'By ${_book.author}',
                          style: TextStyle(
                            fontSize: 14,
                            color: Colors.grey.shade700,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                          decoration: BoxDecoration(
                            color: isAvailable
                                ? const Color(0xFFE8F5E9)
                                : const Color(0xFFFFEBEE),
                            borderRadius: BorderRadius.circular(6),
                          ),
                          child: Text(
                            isAvailable
                                ? 'Available: ${_book.available} / ${_book.quantity}'
                                : 'Currently Unavailable',
                            style: TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.bold,
                              color: isAvailable
                                  ? const Color(0xFF2E7D32)
                                  : const Color(0xFFC62828),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),

            // Metadata Grid / List
            const Text(
              'Information',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: Color(0xFF1E293B),
              ),
            ),
            const SizedBox(height: 12),
            _buildInfoRow(Icons.pin, 'ISBN', _book.isbn),
            _buildInfoRow(Icons.school, 'Department', _book.department),
            _buildInfoRow(Icons.shelves, 'Shelf Location', _book.shelf),
            _buildInfoRow(Icons.copy_all, 'Available Copies', '${_book.available} of ${_book.quantity}'),

            const SizedBox(height: 20),

            // Description
            const Text(
              'Description',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: Color(0xFF1E293B),
              ),
            ),
            const SizedBox(height: 8),
            Text(
              _book.description.isNotEmpty
                  ? _book.description
                  : 'No description available for this textbook.',
              style: TextStyle(
                fontSize: 14,
                height: 1.5,
                color: Colors.grey.shade800,
              ),
            ),
            const SizedBox(height: 32),

            // Action Button Area
            if (isAvailable) ...[
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: _isLoading ? null : _handleIssueBook,
                  icon: const Icon(Icons.library_add_check_rounded),
                  label: _isLoading
                      ? const SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: Colors.white,
                          ),
                        )
                      : const Text(
                          'Issue Book',
                          style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                        ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF0D47A1),
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                    elevation: 0,
                  ),
                ),
              ),
            ] else ...[
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(12),
                margin: const EdgeInsets.only(bottom: 12),
                decoration: BoxDecoration(
                  color: const Color(0xFFFFEBEE),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Row(
                  children: [
                    Icon(Icons.info_outline, color: Color(0xFFC62828), size: 20),
                    SizedBox(width: 8),
                    Text(
                      'All copies are currently issued to students.',
                      style: TextStyle(color: Color(0xFFC62828), fontSize: 13),
                    ),
                  ],
                ),
              ),
              SizedBox(
                width: double.infinity,
                child: OutlinedButton.icon(
                  onPressed: _handleRequestBook,
                  icon: const Icon(Icons.bookmark_add_outlined),
                  label: const Text(
                    'Request This Book',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                  ),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: const Color(0xFF0D47A1),
                    side: const BorderSide(color: Color(0xFF0D47A1)),
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildInfoRow(IconData icon, String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: [
          Icon(icon, size: 20, color: Colors.grey.shade600),
          const SizedBox(width: 12),
          Text(
            label,
            style: TextStyle(
              fontSize: 14,
              color: Colors.grey.shade600,
            ),
          ),
          const Spacer(),
          Text(
            value,
            style: const TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w600,
              color: Color(0xFF1E293B),
            ),
          ),
        ],
      ),
    );
  }
}
